		<!-- start footer Area -->		
			<footer class="footer-area section-gap">
				<div class="container">
					<div class="row">
					<div class="col-lg-6  col-md-12">
							<div class="single-footer-widget newsletter">
								<h6><u>About Our Company</u></h6>
								<a class="navbar-brand" href="<?=base_url();?>">
						  	<img src="<?=base_url(); ?>assets/dcentevent/img/logo-footer.png" alt="">
						  </a>
								<p align="justify">Dcent Entertainment & Event planners specializes in corporate functions, fairs, galas, festivals all types of special events. From dance bands and wedding planning, cultural events and family shows, Dcent Entertainment can provide the service and expertise to fulfill all your needs.</p>		
							</div>
						</div>
						
						<div class="col-lg-3  col-md-12">
							<div class="single-footer-widget">
								<h6><u>Important Links</u></h6>
								<ul class="footer-nav">
									<li><a href="<?=base_url();?>">Home</a></li>
									<li><a href="<?=base_url('home/about');?>">About Us</a></li>
									<li><a href="<?=base_url('home/contact');?>">Contact Us</a></li>
									<li><a href="<?=base_url('home/career');?>">Career</a></li>
									<li><a href="<?=base_url('home/grievances');?>">Grievances</a></li>
								</ul>
							</div>
						</div>
						
						<div class="col-lg-3  col-md-12">
							<div class="single-footer-widget mail-chimp">
								<h6 class="mb-20"><u>Registered Office</u></h6>
								<address>
                        <ul >
							<li><i class="fa fa-map-marker" aria-hidden="true"></i>&nbsp&nbsp<span>403, Gupta Tower, Radium Road, Kutchery Chowk, Ranchi, Jharkhand (India) </span></li><br>
                            <li><i class="fa fa-phone" aria-hidden="true"></i>&nbsp&nbsp07759994411</li><br>
							<li><i class="fa fa-phone" aria-hidden="true"></i>&nbsp&nbsp0651-2361622</li>
                        </ul>
                    </address>
							</div>
						</div>						
					</div>

					<div class="copyright_area" style="display:block; text-align:center;width:100%;color: white;">
            © Copyrights 2019. DCENT ENTERTAINMENT & EVENT PLANNERS PRIVATE LIMITED <br>Powered By <a target="_blank" href="https://www.fizzyhomes.com">Fizzy Homes.</a>
        </div>
				</div>
			</footer>
			<!-- End footer Area -->		
