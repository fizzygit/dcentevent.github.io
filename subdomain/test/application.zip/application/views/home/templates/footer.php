
			<script src="<?=base_url(); ?>assets/dcentevent/js/vendor/jquery-2.2.4.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
			<script src="<?=base_url(); ?>assets/dcentevent/js/vendor/bootstrap.min.js"></script>
			<script src="<?=base_url(); ?>assets/dcentevent/js/jquery.ajaxchimp.min.js"></script>
			<script src="<?=base_url(); ?>assets/dcentevent/js/parallax.min.js"></script>			
			<script src="<?=base_url(); ?>assets/dcentevent/js/owl.carousel.min.js"></script>			
			<script src="<?=base_url(); ?>assets/dcentevent/js/jquery.sticky.js"></script>
			<script src="<?=base_url(); ?>assets/dcentevent/js/jquery.DonutWidget.min.js"></script>
			<script src="<?=base_url(); ?>assets/dcentevent/js/jquery.magnific-popup.min.js"></script>			
			<script src="<?=base_url(); ?>assets/dcentevent/js/main.js"></script>	
		</body>
	</html>
