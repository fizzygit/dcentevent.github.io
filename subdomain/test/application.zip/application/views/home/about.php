			 <!-- Banner area -->
    <section class="banner_area" data-stellar-background-ratio="0.5">
        <h2>About Us</h2>
        <ol class="breadcrumb">
            <li><a href="<?=base_url();?>">Home</a></li>
            <li><a href="#" class="active">About Us</a></li>
        </ol>
    </section>
    <!-- End Banner area -->	


			<!-- Start Generic Area -->
			<section class="about-generic-area section-gap">
				<div class="container border-top-generic">
					<h3 class="about-title mb-30">About Us</h3>
					<div class="row">
						<div class="col-md-8">
							<div class="img-text">
								
								<p align="justify">Dcent Entertainment & Event planners specializes in corporate functions, fairs, galas, festivals all types of special events. From dance bands and wedding planning, cultural events and family shows, Dcent Entertainment can provide the service and expertise to fulfill all your needs. 

Dcent is a well integrated event & entertainment company. Our combined efforts enable us to offer strategy and creativity in all the events we execute. 
</p>
<p align="justify">It'a main mission is to expand Dcent into new markets while promoting and expanding our scope of management. Maintain growth with the collaboration and the effort of all the members of the team and with the supports of our clients. Also, it has a very clear vision to build up a prominent & premier event management company delivering one stop solution globally.</p>
							</div>
						</div>
						
						<div class="col-md-4">
							<div class="img-text">
								<img src="<?=base_url();?>assets/dcentevent/img/about-us.jpg">
								
							</div>
						</div>

					</div>
				</div>
			</section>
			<!-- End Generic Start -->		
